# BIGKompas



---

# BIGKompas versiebeheer

Huidige versie: BIGKompas v1.0-beta  
Sprint: 6A.14  
Build: 0017  
Datum: 18-06-2026  

Canary:
"Stuwmeergrafiek toont 6500 LOGO-houders tegenover 691 opleidingsplaatsen."

## Releasegeschiedenis

### 6A.14 — Build 0017
- Oude canary-verwijzingen in pagina-inhoud opgeschoond
- GZ-opleidingsroute overzichtelijker herbouwd
- Capaciteitsbeleid uitgebreid met cijfers en grafische stuwmeer-weergave
- LOGO-voorwaarden concreter uitgewerkt
- ZPM-pagina sterker gekoppeld aan positie van psychologen zonder BIG
- Tijdlijn gekoppeld aan capaciteitsgrafiek

### 6A.13 — Build 0016
- LOGO-pagina uitgebreid met actuele vooropleidingseisen
- EVC-pagina uitgebreid
- Tijdlijn uitgebreid

### 6A.12 — Build 0015
- Cache-busting toegevoegd
- Bronnenlinks toegevoegd


### 6A.15 — Build 0018
- Canary systeem verwijderd
- Voorbereiding uitbreiding BIG, EVC en tijdlijn
- Voorbereiding belasting GZ-psychologen sectie

### 6A.16 — Build 0019
- Tijdlijn uitgebreid met betekenis voor BIG-loze psychologen
- Reacties van NIP en andere partijen toegevoegd
- Belasting van GZ-psychologen toegevoegd
